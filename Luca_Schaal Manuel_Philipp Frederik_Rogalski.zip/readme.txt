compilieren mit make oder 
gcc -I include src/*
